/**
 * This package contains reusable or cross-cutting view-related classes.
 */
@NullMarked
package unl.practica.com.base.ui.view;

import org.jspecify.annotations.NullMarked;
