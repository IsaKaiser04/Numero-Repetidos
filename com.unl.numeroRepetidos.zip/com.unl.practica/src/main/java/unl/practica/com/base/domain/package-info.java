/**
 * This package contains reusable domain classes.
 */
@NullMarked
package unl.practica.com.base.domain;

import org.jspecify.annotations.NullMarked;
