/**
 * This package contains reusable UI components.
 */
@NullMarked
package unl.practica.com.base.ui.component;

import org.jspecify.annotations.NullMarked;
